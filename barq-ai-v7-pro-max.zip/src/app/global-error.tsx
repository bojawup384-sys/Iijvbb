"use client";

/** Last line of defence: even a crash of the root layout never shows a white page. */
export default function GlobalError({ reset }: { error: Error; reset: () => void }) {
  return (
    <html lang="ar" dir="rtl" style={{ background: "#08100d", colorScheme: "dark" }}>
      <body
        style={{
          margin: 0,
          minHeight: "100dvh",
          display: "grid",
          placeItems: "center",
          background: "radial-gradient(60% 45% at 50% 0%, rgba(38,160,111,.28), transparent 70%), #08100d",
          color: "#e3ddd0",
          fontFamily: "system-ui, Tahoma, sans-serif",
          textAlign: "center",
          padding: 24,
        }}
      >
        <div style={{ maxWidth: 360 }}>
          <div style={{ fontSize: 48 }}>⚡</div>
          <h1 style={{ fontSize: 22, margin: "14px 0 8px", color: "#faf7f1" }}>برق يحتاج إعادة تشغيل</h1>
          <p style={{ color: "#a39b8b", lineHeight: 1.9, margin: "0 0 22px" }}>صار خلل غير متوقع. اضغط الزر وكمّل.</p>
          <button
            onClick={reset}
            style={{ border: 0, borderRadius: 12, padding: "12px 28px", fontWeight: 700, fontSize: 15, color: "#fff", background: "#168257" }}
          >
            إعادة المحاولة
          </button>
        </div>
      </body>
    </html>
  );
}
